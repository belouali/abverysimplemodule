from abverysimplemodule.extras.multiply import multiply
from abverysimplemodule.extras.divide import divide
